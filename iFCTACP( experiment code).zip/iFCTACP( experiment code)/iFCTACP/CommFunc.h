///////////////////////////////////////////////////////
// File: CommonFunc
// Desc: Common function + Hearder files
//
// Author: Zhang Kang
// Date: 2013/09/06
///////////////////////////////////////////////////////
#pragma  once
#define DOUBLE_MAX 1e10
#define COMPUTE_RIGHT

#include<opencv2/opencv.hpp>
#include<string>
#include<iostream>
#include<bitset>
using namespace std;
using namespace cv;

//
// Opencv Lib 2.4.6
//
#ifdef _DEBUG
#pragma comment( lib, "opencv_calib3d341d.lib" )
//#pragma comment( lib, "opencv_contrib341d.lib" )
#pragma comment( lib, "opencv_core341d.lib" )
#pragma comment( lib, "opencv_features2d341d.lib" )
#pragma comment( lib, "opencv_flann341d.lib" )
//#pragma comment( lib, "opencv_gpu341d.lib" )
#pragma comment( lib, "opencv_highgui341d.lib" )
#pragma comment( lib, "opencv_imgproc341d.lib" )
//#pragma comment( lib, "opencv_legacy341d.lib" )
#pragma comment( lib, "opencv_ml341d.lib" )
//#pragma comment( lib, "opencv_nonfree341d.lib" )
#pragma comment( lib, "opencv_objdetect341d.lib" )
#pragma comment( lib, "opencv_photo341d.lib" )
#pragma comment( lib, "opencv_stitching341d.lib" )
#pragma comment( lib, "opencv_superres341d.lib" )
//#pragma comment( lib, "opencv_ts341d.lib" )
#pragma comment( lib, "opencv_video341d.lib" )
#pragma comment( lib, "opencv_videostab341d.lib" )
#else
#pragma comment( lib, "opencv_calib3d341.lib" )
//#pragma comment( lib, "opencv_contrib341.lib" )
#pragma comment( lib, "opencv_core341.lib" )
#pragma comment( lib, "opencv_features2d341.lib" )
#pragma comment( lib, "opencv_flann341.lib" )
//#pragma comment( lib, "opencv_gpu341.lib" )
#pragma comment( lib, "opencv_highgui341.lib" )
#pragma comment( lib, "opencv_imgproc341.lib" )
//#pragma comment( lib, "opencv_legacy341.lib" )
#pragma comment( lib, "opencv_ml341.lib" )
//#pragma comment( lib, "opencv_nonfree341.lib" )
#pragma comment( lib, "opencv_objdetect341.lib" )
#pragma comment( lib, "opencv_photo341.lib" )
#pragma comment( lib, "opencv_stitching341.lib" )
#pragma comment( lib, "opencv_superres341.lib" )
//#pragma comment( lib, "opencv_ts341.lib" )
#pragma comment( lib, "opencv_video341.lib" )
#pragma comment( lib, "opencv_videostab341.lib" )
#endif

// output matrix
template<class T>
void PrintMat( const Mat& mat )
{
	int rows = mat.rows;
	int cols = mat.cols;
	printf( "\n%d x %d Matrix\n", rows, cols );
	for( int r = 0; r < rows; r ++ ) {
		for( int c = 0; c < cols; c ++  ) {
			cout << mat.at<T>( r, c ) << "\t";
		}
		printf( "\n" );
	}
	printf( "\n" );
}
