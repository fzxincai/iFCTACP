/*
 * ctmf.c - Constant-time median filtering
 * Copyright (C) 2006  Simon Perreault
 *
 * Reference: S. Perreault and P. H��bert, "Median Filtering in Constant Time",
 * IEEE Transactions on Image Processing, September 2007.
 *
 * This program has been obtained from http://nomis80.org/ctmf.html. No patent
 * covers this program, although it is subject to the following license:
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Contact:
 *  Laboratoire de vision et syst��mes num��riques
 *  Pavillon Adrien-Pouliot
 *  Universit�� Laval
 *  Sainte-Foy, Qu��bec, Canada
 *  G1K 7P4
 *
 *  perreaul@gel.ulaval.ca
 */

#ifndef CTMF_H
#define CTMF_H

#ifdef __cplusplus
extern "C" {
#endif

void ctmf(const unsigned char* src, unsigned char* dst,int width, int height,int src_step_row, int dst_step_row,int r, int channels, unsigned long memsize);

#ifdef __cplusplus
}
#endif

#endif
