#pragma once


#ifndef AD_CENSUS_CROSS_AGGREGATOR_H_
#define AD_CENSUS_CROSS_AGGREGATOR_H_

#include "adcensus_types.h"
#include <algorithm>
#include "CommFunc.h"
#include "CAMethod.h"
#include "cross_aggregator.h"



/**
 * \brief ʮ�ֽ�������۾ۺ���
 */
class CROSS :
	public CAMethod
{
public:
	CROSS(void)
	{
		printf("\n\t\tCROSS method for cost aggregation");
	}

	~CROSS(void) {}
public:
	void aggreCV(const Mat& lImg, const Mat& rImg, const int maxDis, Mat* costVol, Mat* cost_compute);

};
#endif

