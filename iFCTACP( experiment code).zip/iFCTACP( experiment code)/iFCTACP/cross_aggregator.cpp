
#include "cross_aggregator.h"

CrossAggregator::CrossAggregator() : width_(0), height_(0), 
cross_L1_(0), cross_L2_(0), cross_t1_(0), cross_t2_(0),
min_disparity_(0), max_disparity_(0), is_initialized_(false) { }

CrossAggregator::~CrossAggregator()
{

}

bool CrossAggregator::Initialize(const sint32& width, const sint32& height, const sint32& min_disparity, const sint32& max_disparity)
{
	width_ = width;
	height_ = height;
	min_disparity_ = min_disparity;
	max_disparity_ = max_disparity;

	const sint32 img_size = width_ * height_;
	const sint32 disp_range = max_disparity_ - min_disparity_;
	if (img_size <= 0 || disp_range <= 0) {
		is_initialized_ = false;
		return is_initialized_;
	}

	// Ϊ����ʮ�ֱ���������ڴ�
	vec_cross_arms_.clear();
	vec_cross_arms_.resize(img_size);

	//ʮ�ֽ���۵�Ȩ�ط����ڴ�
	cross_weight.clear();
	cross_weight.resize(img_size);

	//

	// Ϊ�洢ÿ������֧����������������������ڴ�
	vec_sup_count_[0].clear();
	vec_sup_count_[0].resize(img_size);
	vec_sup_count_[1].clear();
	vec_sup_count_[1].resize(img_size);
	vec_sup_count_tmp_.clear();
	vec_sup_count_tmp_.resize(img_size);

	// Ϊ�ۺϴ�����������ڴ�
	cost_aggr_.resize(img_size * disp_range);

	is_initialized_ = !vec_cross_arms_.empty() 
		&& !vec_sup_count_[0].empty() && !vec_sup_count_[1].empty()
		&& !vec_sup_count_tmp_.empty() && !cost_aggr_.empty();
	return is_initialized_;
}



void CrossAggregator::SetParams(const sint32& cross_L1, const sint32& cross_L2, const sint32& cross_t1,
	const sint32& cross_t2)
{
	cross_L1_ = cross_L1;
	cross_L2_ = cross_L2;
	cross_t1_ = cross_t1;
	cross_t2_ = cross_t2;
}


void CrossAggregator::BuildArms(const Mat& lImg)
{
	
	
	Mat tmp, lGray, lGrdY, lGrdX;
	lImg.convertTo(tmp, CV_32F);
	cvtColor(tmp, lGray, CV_RGB2GRAY);
	Sobel(lGray, lGrdX, CV_64F, 1, 0, 1);
	Sobel(lGray, lGrdY, CV_64F, 0, 1, 1);
	lGrdX.convertTo(lGrdX, CV_64F, 255.0f);
	lGrdY.convertTo(lGrdY, CV_64F, 255.0f);
//	lGrdX += 0.5;
//	lGrdY += 0.5;
	Mat Grd;
	lGrdX.copyTo(Grd);
	double gmax = 0;
	for (int i = 1; i < height_ - 1; i++) {
		for (int j = 1; j < width_ - 1; j++) {
			double t = 0 ;
			for (int r = -1; r <= 1; r++) {
				for (int c = -1; c <= 1; c++) {
			
					t+=abs(lGrdX.ptr<double>(i + r)[j + c]) + abs(lGrdY.ptr<double>(i + r)[j + c]);
				}
			}
			Grd.ptr<double>(i)[j] = t/9.0;
			//printf("y:%f\n", Grd.ptr<double>(i)[j]);
			if (Grd.ptr<double>(i)[j] > gmax)
			{
				gmax = Grd.ptr<double>(i)[j];
			}
		}
	}
	

	//�����ؼ���ʮ�ֽ����
	for (sint32 y = 0; y < height_; y++) {
		for (sint32 x = 0; x < width_; x++) {
			CrossArm& arm = vec_cross_arms_[y * width_ + x];
			Weight& weight = cross_weight[y * width_ + x];
			FindHorizontalArm(x, y, arm.left, arm.right, lImg, Grd, lGray,weight,gmax);
			FindVerticalArm(x, y, arm.top, arm.bottom, lImg, Grd, lGray, weight,gmax);

		}
	}
}


void CrossAggregator::Aggregate(const sint32& num_iters, Mat* costVol, const Mat& lImg)
{
	if (!is_initialized_) {
		return;
	}

	const sint32 disp_range = max_disparity_- min_disparity_;

	// �������ص�ʮ�ֽ����
	BuildArms(lImg);

	// ���۾ۺ�
	// horizontal_first ������ˮƽ����ۺ�
	bool horizontal_first = true;

	// �������־ۺϷ���ĸ�����֧������������
	ComputeSupPixelCount();

	// �Ƚ��ۺϴ��۳�ʼ��Ϊ��ʼ����
	//memcpy(&cost_aggr_[0], cost_init_, width_*height_*disp_range * sizeof(float32));

	// ������ۺ�
	for (sint32 k = 0; k < num_iters; k++) {
		for (sint32 d = min_disparity_; d < max_disparity_; d++) {
			AggregateInArms(d, horizontal_first,costVol, lImg);
		}
		// ��һ�ε���������˳��
		horizontal_first = !horizontal_first;
		printf("CA-");
	}
	
}

CrossArm* CrossAggregator::get_arms_ptr()
{
	return &vec_cross_arms_[0];
}

float32* CrossAggregator::get_cost_ptr()
{
	if (!cost_aggr_.empty()) {
		return &cost_aggr_[0];
	}
	else {
		return nullptr;
	}
}

void CrossAggregator::FindHorizontalArm(const sint32& x, const sint32& y, uint8& left, uint8& right, const Mat& lImg,const Mat& Grd, const Mat& lGray, Weight& weight,  double gmax)const
{
	
	// �������ݵ�ַ	
	const auto img0 = lImg.ptr<double>(y) + 3 * x;
	// ������ɫֵ
	const ADColor color0(img0[0]*255, img0[1]*255, img0[2]*255);	

	left = right = 0;
	//�������ұ�,����ۺ��ұ�
	sint32 dir = -1;
	for (sint32 k = 0; k < 2; k++) {
		// �����ֱ������������
		// �۳����ó���cross_L1
		auto img = img0 + dir * 3;
		auto color_last = color0;
		sint32 xn = x + dir;

		int L1 = cross_L1_;
		int L2 = cross_L2_;
		double t1 = cross_t1_;
		double t2 = cross_t2_;
				

		//�¼ӵ�
		
		if (Grd.ptr<double>(y)[x] > qf)
	
		{
			L1 = aa*L1;
			L2= bb*L2;
			//t1 = 0.5*t1;
			t2 = dd*t2;
		}//�¼ӵ�
				
		for (sint32 n = 0; n < std::min(L1, MAX_ARM_LENGTH); n++) {
			 
			
			// �߽紦��
			if (k == 0) {
				if (xn < 0) {
					break;
				}
			}
			else {
				if (xn == width_) {
					break;
				}
			}

			// ��ȡ��ɫֵ
			const ADColor color(img[0]*255, img[1]*255, img[2]*255);
			// ��ɫ����1���������غͼ������ص���ɫ���룩
			const sint32 color_dist1 = ColorDist(color, color0);
									
			double w = double(L1 - n);
			
			t2 = -exp(-w /ee)*t2 + t2;
							
			if (color_dist1 >= t1) {
				break;
			}
			sint32 color_dist2;
			// ��ɫ����2���������غ�ǰһ�����ص���ɫ���룩
			if (n > 0) {
				color_dist2 = ColorDist(color, color_last);
				if (color_dist2 >= t1) {
					break;
				}
			}

			// �۳�����L2����ɫ������ֵ��СΪt2
			if (n + 1 > L2) {
				if (color_dist1 >= t2) {
					break;
				}
				
			}

			
			if (k == 0) {
				left++;
			
			}
			else {
				right++;
			
			}
			color_last = color;
			xn += dir;
			img += dir * 3;
		}
				
		dir = -dir;
	}	
}

void CrossAggregator::FindVerticalArm(const sint32& x, const sint32& y, uint8& top, uint8& bottom, const Mat& lImg,const Mat& Grd, const Mat& lGray, Weight& weight, double gmax)const
{		
	const auto img0 = lImg.ptr<double>(y) + 3 * x;
	// ������ɫֵ
	const ADColor color0(img0[0]*255, img0[1]*255, img0[2]*255);
	const double * img;
	top = bottom = 0;
	//�������±�,���ϱۺ��±�\
	
	sint32 dir = -1;
	for (sint32 k = 0; k < 2; k++) {
		// �����ֱ������������
		// �۳����ó���cross_L1
		sint32 yn = y + dir;

		int L1 = cross_L1_;
		int L2 = cross_L2_;
		double t1 = cross_t1_;
		double t2 = cross_t2_;
		

		//�¼ӵ�
		
		if (Grd.ptr<double>(y)[x] > qf)				
		{
			L1 = aa*L1;
			L2 = bb*L2;
			//t1 = 0.75*t1;
			t2 = dd*t2;
		}//�¼ӵ�

		if(k==0){
			if (yn < 0) {

				dir = -dir;
				continue;
			}
			else {
				img = lImg.ptr<double>(yn) + x * 3;
			}
		}
		else {
			if (yn == height_) {
				break;
			}
			else {
				img = lImg.ptr<double>(yn) + x * 3;
			}
		}
		//img = img0 + dir * width_ * 3;

		auto color_last = color0;
		
		for (sint32 n = 0; n < std::min(L1, MAX_ARM_LENGTH); n++) {
			
				
			// ��ȡ��ɫֵ
			const ADColor color(img[0]*255, img[1]*255, img[2]*255);
			// ��ɫ����1���������غͼ������ص���ɫ���룩
			const sint32 color_dist1 = ColorDist(color, color0);
			
			double w = double(L1 - n);
		
			t2 = -exp(-w / ee)*t2 + t2;
			
			if (color_dist1 >= t1) {
				break;
			}
			 sint32 color_dist2;
			// ��ɫ����2���������غ�ǰһ�����ص���ɫ���룩
			if (n > 0) {
				  color_dist2 = ColorDist(color, color_last);
				if (color_dist2 >= t1) {
					break;
				}
			}

			// �۳�����L2����ɫ������ֵ��СΪt2
			if (n + 1 > L2) {
				if (color_dist1 >= t2) {
					break;
				}			
			}

			if (k == 0) {
				top++;
				double w1 = 0.5*color_dist1 + 0.5*top;
				weight.Top[top] = exp(-(w1)/5.0);
			}
			else {
				bottom++;
			
			}
			color_last = color;
			yn += dir;
			
			if (k == 0) {
				if (yn < 0) {
					break;
				}
				else {
					img = lImg.ptr<double>(yn) + x * 3;
				}
			}
			else {
				if (yn == height_) {
					break;
				}
				else {
					img = lImg.ptr<double>(yn) + x * 3;
				}
			}
		}
		dir = -dir;
	}
}

void CrossAggregator::ComputeSupPixelCount()
{
	
	bool horizontal_first = true;
	for (sint32 n = 0; n < 2; n++) {
		// n=0 : horizontal_first; n=1 : vertical_first
		const sint32 id = horizontal_first ? 0 : 1;
		for (sint32 k = 0; k < 2; k++) {
			// k=0 : pass1; k=1 : pass2
			for (sint32 y = 0; y < height_; y++) {
				for (sint32 x = 0; x < width_; x++) {
					// ��ȡarm��ֵ
					auto& arm = vec_cross_arms_[y*width_ + x];
					sint32 count = 0;
					if (horizontal_first) {
						if (k == 0) {
							// horizontal
							for (sint32 t = -arm.left; t <= arm.right; t++) {
								count++;
							}
						}
						else {
							// vertical
							for (sint32 t = -arm.top; t <= arm.bottom; t++) {
								count += vec_sup_count_tmp_[(y + t)*width_ + x];						
								
							}
						}
					}
					else {
						if (k == 0) {
							// vertical
							for (sint32 t = -arm.top; t <= arm.bottom; t++) {
								count++;
							}
						}
						else {
							// horizontal
							for (sint32 t = -arm.left; t <= arm.right; t++) {
								count += vec_sup_count_tmp_[y*width_ + x + t];						
								
							}
						}
					}
					if (k == 0) {
						vec_sup_count_tmp_[y*width_ + x] = count;
					}
					else {
						vec_sup_count_[id][y*width_ + x] = count;
					}
									
					
				}
	
			}
		}
		horizontal_first = !horizontal_first;
	}
	
}

void CrossAggregator::AggregateInArms(const sint32& disparity, const bool& horizontal_first,Mat* costVol, const Mat& lImg)
{
	// �˺����ۺ��������ص��Ӳ�Ϊdisparityʱ�Ĵ���

	if (disparity < min_disparity_ || disparity >= max_disparity_) {
		return;
	}
	const auto disp = disparity - min_disparity_;
	const sint32 disp_range = max_disparity_ - min_disparity_;
	if (disp_range <= 0) {
		return;
	}

	
	// costVol[disparity].copyTo(vec_cost_tmp_[0]);
	Mat vec_cost_tmp_1, vec_cost_tmp_2(height_,width_, costVol[disparity].type());
	costVol[disparity].copyTo(vec_cost_tmp_1);
	
	// �����ؾۺ�
	const sint32 ct_id = horizontal_first ? 0 : 1;
	for (sint32 k = 0; k < 2; k++) {
		// k==0: pass1

		// k==1: pass2
		//printf("%d\n", k);
		for (sint32 y = 0; y < height_; y++) {
			for (sint32 x = 0; x < width_; x++) {
				// ��ȡarm��ֵ
				auto& arm = vec_cross_arms_[y*width_ + x];
				//��ȡweight��ֵ
				auto& weight = cross_weight[y*width_ + x];
				// �ۺ�
				//printf("%d,%d,%d\t", x,y, disparity);
				float32 cost = 0.0f;
				double sum_lr = 0,sum_tb=0;
				if (horizontal_first) {
					
						
					if (k == 0) {
						
						// horizontal
						for (sint32 t = -arm.left; t <= arm.right; t++) {
							
							cost = cost + (vec_cost_tmp_1.ptr < double > (y)[x + t]);

							
						}
					}
					else {
						
						// vertical
						for (sint32 t = -arm.top; t <= arm.bottom; t++) {
							
						
							
							cost = cost + vec_cost_tmp_2.ptr< double >(y + t)[x];	
							
						}
					}
				}
				else {										
					if (k == 0) {
						
						// vertical
						for (sint32 t = -arm.top; t <= arm.bottom; t++) {
							
							cost = cost + vec_cost_tmp_1.ptr< double >(y + t)[x];							
						}
					}
					else {
						
						// horizontal
						for (sint32 t = -arm.left; t <= arm.right; t++) {
							

							cost = cost + vec_cost_tmp_2.ptr< double >(y)[x + t];
							
						}
					}
				}
				if (k == 0) {
					
					vec_cost_tmp_2.ptr< double >(y)[x] = cost;
				}
				else {
					
					costVol[disparity].ptr< double >(y)[x]= cost / (vec_sup_count_[ct_id][y*width_ + x]);
					
				}
			}
		}
	}
}

