#include "CommFunc.h"
#include "iFCTACP.h"
#include "adcensus_types.h"

SSCA::SSCA(const Mat l, const Mat r, const int m, const int d)
	: lImg( l ), rImg( r ), maxDis( m ), disSc( d )
{
	// all input image must be in CV_64FC3 format
	CV_Assert( lImg.type() == CV_64FC3 && rImg.type() == CV_64FC3 );
	wid = lImg.cols;
	hei = lImg.rows;
	// init disparity map
	lDis = Mat::zeros( hei, wid, CV_8UC1 );

#ifdef COMPUTE_RIGHT
	rDis = Mat::zeros( hei, wid, CV_8UC1 );
	lSeg = Mat::zeros( hei, wid, CV_8UC3 );
	lChk = Mat::zeros( hei, wid, CV_8UC1 );
#endif
	// init cost volum data
	costVol = new Mat[ maxDis  ];
	cost_compute = new Mat[maxDis];
	for( int mIdx = 0; mIdx < maxDis; mIdx ++ ) {
		costVol[ mIdx ] = Mat::zeros( hei, wid, CV_64FC1 );
		cost_compute[mIdx] = Mat::zeros(hei, wid, CV_64FC1);
	}
#ifdef COMPUTE_RIGHT
	rCostVol = new Mat[ maxDis ];
	for( int mIdx = 0; mIdx < maxDis; mIdx ++ ) {
		rCostVol[ mIdx ] = Mat::zeros( hei, wid, CV_64FC1 );
	}
#endif
}



SSCA::~SSCA(void)
{
	delete [] costVol;
#ifdef COMPUTE_RIGHT
	delete [] rCostVol;
#endif
}
// get left disparity
Mat SSCA::getLDis()
{
	return lDis;
}
#ifdef COMPUTE_RIGHT
// get right disparity
Mat SSCA::getRDis()
{
	return rDis;
}
Mat SSCA::getLSeg()
{
	return lSeg;
}
Mat SSCA::getLChk()
{
	return lChk;
}
#endif
//
// Save Cost Volume
//
void SSCA::saveCostVol(const string fn)
{
	int myY = 53;
	int startX = 285;
	int endX   = 424;

	// save as matlab order
	FILE* fp = fopen( fn.c_str(), "w" );

	for( int d = 1; d < maxDis; d ++ ) {
		printf( "-s-v-" );
		for( int x = 0; x < wid; x ++ ) {
			for( int y = 0; y < hei; y ++ ) {
				if( y == myY && x >= startX && x <= endX ) {
					double* cost = costVol[ d ].ptr<double>( y );
					fprintf( fp, "%lf  ", cost[ x ] );
				}
			}
		}
		fprintf( fp, "\n" );
	}
	fclose( fp );
}
//
// Add previous cost volume from pyramid
//
void SSCA::AddPyrCostVol(SSCA *pre, const double COST_ALPHA )
{
	printf( "\n\tAdd Pyramid Cost: COST_ALPHA = %.2lf", COST_ALPHA );
	for( int d = 1; d < maxDis; d ++ ) {
		int pD = ( d + 1 ) / 2;
		printf( ".a.p." );
		for( int y = 0; y < hei; y ++ ) {
			int pY = y / 2;
			double* cost = costVol[ d ].ptr<double>( y );
			double* pCost = pre->costVol[ pD ].ptr<double>( pY );
			for( int x = 0; x < wid; x ++ ) {
				int pX = x / 2;
				cost[ x ] = COST_ALPHA * cost[ x ] +
					( 1 - COST_ALPHA ) * pCost[ pX ];

			}
		}
	}
#ifdef COMPUTE_RIGHT
	for( int d = 1; d < maxDis; d ++ ) {
		int pD = ( d + 1 ) / 2;
		printf( "r.a.p." );
		for( int y = 0; y < hei; y ++ ) {
			int pY = y / 2;
			double* cost = rCostVol[ d ].ptr<double>( y );
			double* pCost = pre->rCostVol[ pD ].ptr<double>( pY );
			for( int x = 0; x < wid; x ++ ) {
				int pX = x / 2;
				cost[ x ] = COST_ALPHA * cost[ x ] +
					( 1 - COST_ALPHA ) * pCost[ pX ];

			}
		}
	}
#endif
}
//
// 1. Cost Computation
//
/*sint32 ColorDist(const ADColor& c1, const ADColor& c2) {
	return std::max(abs(c1.r - c2.r), std::max(abs(c1.g - c2.g), abs(c1.b - c2.b)));
}
sint32 ColorDist(const ADColor& c1, const ADColor& c2) {
	return std::max(abs(c1.r - c2.r), std::max(abs(c1.g - c2.g), abs(c1.b - c2.b)));
}*/



void SSCA::CostCompute( CCMethod* ccMtd )
{
	
	printf( "\n\tCost Computation:" );
	if( ccMtd ) {
		ccMtd->buildCV( lImg, rImg, maxDis, costVol ,cost_compute);
		Mat xx = imread("E://other_app//����ƥ�乤��//Error_Non_31//Data//teddy//groundtruth.png");
		
		
#ifdef COMPUTE_RIGHT
		ccMtd->buildRightCV( lImg, rImg, maxDis, rCostVol);
#endif
	} else {
		printf( "\n\t\tDo nothing" );
	}
	
}
//
// 2. Cost Aggregation
//
void SSCA::CostAggre( CAMethod* caMtd )
{
	printf( "\n\tCost Aggregation:" );
	
	if( caMtd ) {
		caMtd->aggreCV( lImg, rImg, maxDis, costVol,cost_compute );		
#ifdef COMPUTE_RIGHT
		caMtd->aggreCV( rImg, lImg, maxDis, rCostVol ,cost_compute);
#endif		
	} else {
		printf( "\n\t\tDo nothing" );
	}
	
}
//
// 3. Match
//
void SSCA::Match( void )
{
	printf( "\n\tMatch" );
	for( int y = 0; y < hei; y ++ ) {
		uchar* lDisData = ( uchar* ) lDis.ptr<uchar>( y );
		for( int x = 0; x < wid; x ++ ) {
			double minCost = DOUBLE_MAX;
			int    minDis  = 0;
			for( int d = 1; d < maxDis; d ++ ) {
				double* costData = ( double* )costVol[ d ].ptr<double>( y );
				if( costData[ x ] < minCost ) {
					minCost = costData[ x ];
					minDis  = d;
				}
			}
			lDisData[ x ] = minDis * disSc;
		}
	}

#ifdef COMPUTE_RIGHT
	for( int y = 0; y < hei; y ++ ) {
		uchar* rDisData = ( uchar* ) rDis.ptr<uchar>( y );
		for( int x = 0; x < wid; x ++ ) {
			double minCost = DOUBLE_MAX;
			int    minDis  = 0;
			for( int d = 1; d < maxDis; d ++ ) {
				double* costData = ( double* )rCostVol[ d ].ptr<double>( y );
				if( costData[ x ] < minCost ) {
					minCost = costData[ x ];
					minDis  = d;
				}
			}
			rDisData[ x ] = minDis * disSc;
		}
	}
#endif
}
//
// 4. Post Process;
//
void SSCA::PostProcess( PPMethod* ppMtd )
{
	printf( "\n\tPostProcess:" );
	if( ppMtd ) {
#ifdef COMPUTE_RIGHT
		ppMtd->postProcess( lImg, rImg, maxDis, disSc, lDis, rDis, lSeg, lChk );
#endif		
		//ppMtd->postProcess(lImg, rImg, maxDis, disSc, lDis, rDis, lSeg, lChk);
	} else {
		printf( "\n\t\tDo nothing" );
	}
}




inline sint32 ColorDist(const ADColor& c1, const ADColor& c2) {
	return std::max(abs(c1.r - c2.r), std::max(abs(c1.g - c2.g), abs(c1.b - c2.b)));
}
void SSCA::ScanlineOptimizeLeftRight(Mat* costVol, Mat* cost_compute, bool is_forward) {
	const auto width = wid;
	const auto height =hei;
	const auto min_disparity = 0;
	const auto max_disparity = maxDis;
	const auto p1 = 1.0f;
	const auto p2 = 3.0f;
	const auto tso = 15;
	//printf("%d\t",cost_so_dst[0].ptr<double>(height-1)[width-1]);
	//printf("%d\t", cost_so_src[0].ptr<double>(height - 1)[width - 1]);
	assert(width > 0 && height > 0 && max_disparity > min_disparity);

	// �ӲΧ
	const sint32 disp_range = max_disparity - min_disparity;

	// ����(��->��) ��is_forward = true ; direction = 1
	// ����(��->��) ��is_forward = false; direction = -1;
	const sint32 direction = is_forward ? 1 : -1;
	// �ۺ�
	for (sint32 y = 0u; y < height; y++) {
		//printf("%d\t", y);
		//printf("%d", sizeof(uchar));
		// ·��ͷΪÿһ�е���(β,dir=-1)������

		//auto cost_init_row = (is_forward) ? (float32 *)(cost_so_src + y * width ) : (float32 *)(cost_so_src + y * width  + (width - 1));
		//auto cost_aggr_row = (is_forward) ? (float32 *)(cost_so_dst + y * width ) : (float32 *)(cost_so_dst + y * width + (width - 1) );
		//auto img_row = (is_forward) ? (img_left_.ptr < float32 > (y)) : img_left_.ptr<float32>(y) + 3 * (width - 1);
		//const auto img_row_r = img_right_ .ptr<float32>(y);

		auto cost_init_row = (is_forward) ? costVol[0].ptr<double>(y) : costVol[0].ptr<double>(y) + (width - 1);
		//auto cost_aggr_row = (is_forward) ? cost_compute[0].ptr<double>(y) : cost_compute[0].ptr<double>(y) + (width - 1);
		auto img_row = (is_forward) ? (double*)(lImg.ptr < double >(y)) : (double*)(lImg.ptr<double>(y) + 3 * (width - 1));
		const auto img_row_r = (double*)(rImg.ptr<double>(y));

		sint32 x = (is_forward) ? 0 : width - 1;

		//printf("ScanlineOptimizeLeftRight:%f", cost_so_src->ptr<double>(y)[0]);
		// ·���ϵ�ǰ��ɫֵ����һ����ɫֵ
//		ADColor color((img_row)[0] * 255, (img_row)[1] * 255, (img_row)[2] * 255);
		ADColor color((img_row)[0], (img_row)[1], (img_row)[2] );
		ADColor color_last = color;

		// ·�����ϸ����صĴ������飬������Ԫ����Ϊ�˱���߽��������β����һ����
		std::vector<double> cost_last_path(disp_range + 4, Large_Float);

		// ��ʼ������һ�����صľۺϴ���ֵ���ڳ�ʼ����ֵ
		//memcpy(cost_aggr_row, cost_init_row, disp_range * sizeof(double));
		//memcpy(&cost_last_path[1], cost_aggr_row, disp_range * sizeof(double));
		for (int i = 0; i < disp_range; i++) {
			cost_last_path[1 + i] = costVol[i].ptr<double>(y)[x];
		}
		cost_init_row += direction;
		//cost_aggr_row += direction ;
		img_row += direction * 3;
		x += direction;

		// ·�����ϸ����ص���С����ֵ
		double mincost_last_path = Large_Float;
		for (auto cost : cost_last_path) {
			mincost_last_path = std::min(mincost_last_path, cost);
		}

		// �Է����ϵ�2�����ؿ�ʼ��˳��ۺ�
		for (sint32 j = 0; j < width - 1; j++) {
			color = ADColor(img_row[0] * 255, img_row[1] * 255, img_row[2] * 255);

			const uint8 d1 = ColorDist(color, color_last);
			double d2 = d1;
			double min_cost = Large_Float;
			//printf("%d\t", j);
			for (sint32 d = 0; d < disp_range; d++) {
				const sint32 xr = x - d - min_disparity;
				if (xr > 0 && xr < width - 1) {
					const ADColor color_r = ADColor((img_row_r + 3 * xr)[0] * 255, (img_row_r + 3 * xr)[1] * 255, (img_row_r + 3 * xr)[2] * 255);
					const ADColor color_last_r = ADColor((img_row_r + 3 * (xr - direction))[0] * 255,
						(img_row_r + 3 * (xr - direction))[1] * 255,
						(img_row_r + 3 * (xr - direction))[2] * 255);


					d2 = ColorDist(color_r, color_last_r);
				}

				// ����P1��P2
				float32 P1(0.0f), P2(0.0f);
				if (d1 < tso && d2 < tso) {
					P1 = p1; P2 = p2;
				}
				else if (d1 < tso && d2 >= tso) {
					P1 = p1 / 4; P2 = p2 / 4;
				}
				else if (d1 >= tso && d2 < tso) {
					P1 = p1 / 4; P2 = p2 / 4;
				}
				else if (d1 >= tso && d2 >= tso) {
					P1 = p1 / 10; P2 = p2 / 10;
				}

				// Lr(p,d) = C(p,d) + min( Lr(p-r,d), Lr(p-r,d-1) + P1, Lr(p-r,d+1) + P1, min(Lr(p-r))+P2 ) - min(Lr(p-r))
				//const double  cost = cost_init_row[d];
				const double cost = costVol[d].ptr<double>(y)[x];
				const double l1 = cost_last_path[d + 1];
				const double l2 = cost_last_path[d] + P1;
				const double l3 = cost_last_path[d + 2] + P1;
				const double l4 = mincost_last_path + P2;

				double cost_s = cost + static_cast<double>(std::min(std::min(l1, l2), std::min(l3, l4)));
				cost_s /= 2;

				//cost_aggr_row[d] = cost_s;
				cost_compute[d].ptr<double>(y)[x] = cost_s;
				min_cost = std::min(min_cost, cost_s);
			}

			// �����ϸ����ص���С����ֵ�ʹ�������
			mincost_last_path = min_cost;
			//memcpy(&cost_last_path[1], cost_aggr_row, disp_range * sizeof(double));
			for (int i = 0; i < disp_range; i++) {
				cost_last_path[1 + i] = cost_compute[i].ptr<double>(y)[x];
			}

			// ��һ������
			//cost_init_row += direction;
			//cost_aggr_row += direction ;
			img_row += direction * 3;
			x += direction;

			// ����ֵ���¸�ֵ
			color_last = color;
}
	}
}


void SSCA::ScanlineOptimizeUpDown(Mat* costVol, Mat* cost_compute,  bool is_forward)
{
	const auto width = wid;
	const auto height = hei;
	const auto min_disparity = 0;
	const auto max_disparity = maxDis;
	const auto p1 = 1.0f;
	const auto p2 = 3.0f;
	const auto tso = 15;

	assert(width > 0 && height > 0 && max_disparity > min_disparity);

	// �ӲΧ
	const sint32 disp_range = max_disparity - min_disparity;

	// ����(��->��) ��is_forward = true ; direction = 1
	// ����(��->��) ��is_forward = false; direction = -1;
	const sint32 direction = is_forward ? 1 : -1;

	// �ۺ�
	for (sint32 x = 0; x < width; x++) {
		// ·��ͷΪÿһ�е���(β,dir=-1)������
		auto cost_init_col = (is_forward) ? costVol[0].ptr<double>(0) + x : costVol[0].ptr<double>(height - 1) + x;
		//auto cost_aggr_col = (is_forward) ? cost_compute[0].ptr<double>(0) + x : cost_compute[0].ptr<double>(height - 1) + x;
		auto img_col = (is_forward) ? (double *)(lImg.ptr<double>(0)+3*x) : (double *)(lImg.ptr<double>(height-1)+ 3 * x);
		sint32 y = (is_forward) ? 0 : height - 1;

		// ·���ϵ�ǰ�Ҷ�ֵ����һ���Ҷ�ֵ
		ADColor color(img_col[0]*255, img_col[1]*255, img_col[2]*255);


		ADColor color_last = color;

		// ·�����ϸ����صĴ������飬������Ԫ����Ϊ�˱���߽��������β����һ����
		std::vector<double> cost_last_path(disp_range + 2, Large_Float);

		// ��ʼ������һ�����صľۺϴ���ֵ���ڳ�ʼ����ֵ
		//memcpy(cost_aggr_col, cost_init_col, disp_range * sizeof(double));
		//memcpy(&cost_last_path[1], cost_aggr_col, disp_range * sizeof(double));
		for (int i = 0; i < disp_range; i++) {
			cost_last_path[1 + i] = costVol[i].ptr<double>(y)[x];
		}


		cost_init_col += direction * width * disp_range;
		//cost_aggr_col += direction * width * disp_range;
		img_col += direction * width * 3;
		y += direction;

		// ·�����ϸ����ص���С����ֵ
		double mincost_last_path = Large_Float;
		for (auto cost : cost_last_path) {
			mincost_last_path = std::min(mincost_last_path, cost);
		}

		// �Է����ϵ�2�����ؿ�ʼ��˳��ۺ�
		for (sint32 i = 0; i < height - 1; i++) {
			color = ADColor(img_col[0]*255, img_col[1]*255, img_col[2]*255);


			const uint8 d1 = ColorDist(color, color_last);
			uint8 d2 = d1;
			float32 min_cost = Large_Float;
			for (sint32 d = 0; d < disp_range; d++) {
				const sint32 xr = x - d - min_disparity;
				if (xr > 0 && xr < width - 1) {
					
					const ADColor color_r = ADColor(((rImg.ptr<double>(y) + 3 * xr)[0])*255, ((rImg.ptr<double>(y) + 3 * xr)[1]) * 255, ((rImg.ptr<double>(y) + 3 * xr)[2]) * 255);
					const ADColor color_last_r = ADColor(((rImg.ptr<double>(y - direction) + 3 * xr)[0])*255,
						((rImg.ptr<double>(y - direction) + 3 * xr)[1]) * 255,
						((rImg.ptr<double>(y - direction) + 3 * xr)[2]) * 255);


					d2 = ColorDist(color_r, color_last_r);
				}
				// ����P1��P2
				float32 P1(0.0f), P2(0.0f);
				if (d1 < tso && d2 < tso) {
					P1 = p1; P2 = p2;
				}
				else if (d1 < tso && d2 >= tso) {
					P1 = p1 / 4; P2 = p2 / 4;
				}
				else if (d1 >= tso && d2 < tso) {
					P1 = p1 / 4; P2 = p2 / 4;
				}
				else if (d1 >= tso && d2 >= tso) {
					P1 = p1 / 10; P2 = p2 / 10;
				}

				// Lr(p,d) = C(p,d) + min( Lr(p-r,d), Lr(p-r,d-1) + P1, Lr(p-r,d+1) + P1, min(Lr(p-r))+P2 ) - min(Lr(p-r))
				//const float32  cost = cost_init_col[d];
				const float32  cost = costVol[d].ptr<double>(y)[x];
				const float32 l1 = cost_last_path[d + 1];
				const float32 l2 = cost_last_path[d] + P1;
				const float32 l3 = cost_last_path[d + 2] + P1;
				const float32 l4 = mincost_last_path + P2;

				float32 cost_s = cost + static_cast<float32>(std::min(std::min(l1, l2), std::min(l3, l4)));
				cost_s /= 2;

				cost_compute[d].ptr<double>(y)[x] = cost_s;
				min_cost = std::min(min_cost, cost_s);
			}

			// �����ϸ����ص���С����ֵ�ʹ�������
			mincost_last_path = min_cost;
			//memcpy(&cost_last_path[1], cost_aggr_col, disp_range * sizeof(float32));
			for (int i = 0; i < disp_range; i++) {
				cost_last_path[1 + i] = cost_compute[i].ptr<double>(y)[x];
			}

			// ��һ������
			//cost_init_col += direction * width * disp_range;
			//cost_aggr_col += direction * width * disp_range;
			img_col += direction * width * 3;
			y += direction;

			// ����ֵ���¸�ֵ
			color_last = color;
		}
	}
}

void SSCA::ComputeDisparity() {
	const sint32& min_disparity = 0;
	const sint32& max_disparity = maxDis;
	const sint32 disp_range = maxDis;
	if (disp_range <= 0) {
		return;
	}

	// ��Ӱ���Ӳ�ͼ
	//const auto disparity = disp_left_;

	// ��Ӱ��ۺϴ�������
	//const auto cost_ptr = costVol;

	const sint32 width = wid;
	const sint32 height = hei;

	// Ϊ�˼ӿ��ȡЧ�ʣ��ѵ������ص����д���ֵ�洢���ֲ�������
	std::vector<float32> cost_local(disp_range);

	// ---�����ؼ��������Ӳ�
	for (sint32 i = 0; i < height; i++) {
		uchar* lDisData = (uchar*)lDis.ptr<uchar>(i);
		for (sint32 j = 0; j < width; j++) {
			float32 min_cost = Large_Float;
			sint32 best_disparity = 0;

			// ---�����ӲΧ�ڵ����д���ֵ�������С����ֵ����Ӧ���Ӳ�ֵ
			for (sint32 d = min_disparity; d < max_disparity; d++) {
				const sint32 d_idx = d - min_disparity;
				//const auto& cost = cost_local[d_idx] = cost_ptr[i * width * disp_range + j * disp_range + d_idx];
				const auto& cost = cost_local[d_idx] = costVol[d].ptr<double>(i)[j];

				if (min_cost > cost) {
					min_cost = cost;
					best_disparity = d;
				}
			}
			// ---���������
			if (best_disparity == min_disparity || best_disparity == max_disparity - 1) {
				lDisData[ j] = Invalid_Float;
				continue;
			}
			// �����Ӳ�ǰһ���Ӳ�Ĵ���ֵcost_1����һ���Ӳ�Ĵ���ֵcost_2
			const sint32 idx_1 = best_disparity - 1 - min_disparity;
			const sint32 idx_2 = best_disparity + 1 - min_disparity;
			const float32 cost_1 = cost_local[idx_1];
			const float32 cost_2 = cost_local[idx_2];
			// ��һԪ�������߼�ֵ
			const float32 denom = cost_1 + cost_2 - 2 * min_cost;
			if (denom != 0.0f) {
				lDisData[ j] = static_cast<float32>((best_disparity) + (cost_1 - cost_2) / (denom * 2.0f))*disSc;
			}
			else {
				lDisData[j] = static_cast<float32>(best_disparity)*disSc;
			}
		}
	}
}

void SSCA::ComputeDisparityRight()
 {
	const sint32& min_disparity = 0;
	const sint32& max_disparity = maxDis;
	const sint32 disp_range = maxDis;
	if (disp_range <= 0) {
		return;
	}

	// ��Ӱ���Ӳ�ͼ
	//const auto disparity = disp_right_;
	// ��Ӱ��ۺϴ�������
	//const auto cost_ptr = aggregator_.get_cost_ptr();

	const sint32 width = wid;
	const sint32 height = hei;

	// Ϊ�˼ӿ��ȡЧ�ʣ��ѵ������ص����д���ֵ�洢���ֲ�������
	std::vector<float32> cost_local(disp_range);

	// ---�����ؼ��������Ӳ�
	// ͨ����Ӱ��Ĵ��ۣ���ȡ��Ӱ��Ĵ���
	// ��cost(xr,yr,d) = ��cost(xr+d,yl,d)
	for (sint32 i = 0; i < height; i++) {
		uchar* rDisData = (uchar*)rDis.ptr<uchar>(i);
		for (sint32 j = 0; j < width; j++) {
			float32 min_cost = Large_Float;
			sint32 best_disparity = 0;


			// ---ͳ�ƺ�ѡ�Ӳ��µĴ���ֵ
			for (sint32 d = min_disparity; d < max_disparity; d++) {
				const sint32 d_idx = d - min_disparity;
				const sint32 col_left = j + d;
				if (col_left >= 0 && col_left < width) {
					//const auto& cost = cost_local[d_idx] = cost_ptr[i * width * disp_range + col_left * disp_range + d_idx];
					const auto& cost = cost_local[d_idx] = costVol[d].ptr<double>(i)[col_left];
					if (min_cost > cost) {
						min_cost = cost;
						best_disparity = d;
					}
				}
				else {
					cost_local[d_idx] = Large_Float;
				}
			}

			// ---���������
			if (best_disparity == min_disparity || best_disparity == max_disparity - 1) {
				rDisData[ j] = best_disparity;
				continue;
			}

			// �����Ӳ�ǰһ���Ӳ�Ĵ���ֵcost_1����һ���Ӳ�Ĵ���ֵcost_2
			const sint32 idx_1 = best_disparity - 1 - min_disparity;
			const sint32 idx_2 = best_disparity + 1 - min_disparity;
			const float32 cost_1 = cost_local[idx_1];
			const float32 cost_2 = cost_local[idx_2];
			// ��һԪ�������߼�ֵ
			const float32 denom = cost_1 + cost_2 - 2 * min_cost;
			if (denom != 0.0f) {
				rDisData[j] = static_cast<float32>((best_disparity) + (cost_1 - cost_2) / (denom * 2.0f))*disSc;
			}
			else {
				rDisData[j] = static_cast<float32>(best_disparity)*disSc;
			}
		}
	}
}

void SSCA::OutlierDetection() {

	const sint32 width = wid;
	const sint32 height = hei;

	const float32& threshold = 1.0f;

	// �ڵ������غ���ƥ��������
	auto& occlusions = occlusions_;
	auto& mismatches = mismatches_;
	occlusions.clear();
	mismatches.clear();

	// ---����һ���Լ��
	for (sint32 y = 0; y < height; y++) {
		for (sint32 x = 0; x < width; x++) {
			// ��Ӱ���Ӳ�ֵ
			 int disp = lDis.ptr<double>(y)[x]/disSc;
			if (disp == Invalid_Float) {
				mismatches.emplace_back(x, y);
				continue;
			}

			// �����Ӳ�ֵ�ҵ���Ӱ���϶�Ӧ��ͬ������
			const auto col_right = lround(x - disp);
			if (col_right >= 0 && col_right < width) {
				// ��Ӱ����ͬ�����ص��Ӳ�ֵ
				const auto& disp_r = rDis.ptr<double>(y)[col_right]/disSc;
				// �ж������Ӳ�ֵ�Ƿ�һ�£���ֵ����ֵ�ڣ�
				if (abs(disp - disp_r) > threshold) {
					// �����ڵ�������ƥ����
					// ͨ����Ӱ���Ӳ��������Ӱ���ƥ�����أ�����ȡ�Ӳ�disp_rl
					// if(disp_rl > disp) 
					//		pixel in occlusions
					// else 
					//		pixel in mismatches
					const sint32 col_rl = lround(col_right + disp_r);
					if (col_rl > 0 && col_rl < width) {
						const auto& disp_l = lDis.ptr<double>(y)[col_rl];
						if (disp_l > disp) {
							occlusions.emplace_back(x, y);
						}
						else {
							mismatches.emplace_back(x, y);
						}
					}
					else {
						mismatches.emplace_back(x, y);
					}

					// ���Ӳ�ֵ��Ч
					disp = Invalid_Float;
				}
			}
			else {
				// ͨ���Ӳ�ֵ����Ӱ�����Ҳ���ͬ�����أ�����Ӱ��Χ��
				disp = Invalid_Float;
				mismatches.emplace_back(x, y);
			}
		}
	}
}

void SSCA::ProperInterpolation() {
	const sint32 width = wid;
	const sint32 height = hei;

	const float32 pi = 3.1415926f;
	// ��������г̣�û�б�Ҫ������Զ������
	const sint32 max_search_length = std::max(abs(maxDis), abs(0));

	std::vector<pair<sint32, float32>> disp_collects;
	for (sint32 k = 0; k < 2; k++) {
		auto& trg_pixels = (k == 0) ? mismatches_ : occlusions_;
		if (trg_pixels.empty()) {
			continue;
		}
		std::vector<float32> fill_disps(trg_pixels.size());

		// ��������������
		for (auto n = 0u; n < trg_pixels.size(); n++) {
			auto& pix = trg_pixels[n];
			const sint32 x = pix.first;
			const sint32 y = pix.second;

			// �ռ�16���������������׸���Ч�Ӳ�ֵ
			disp_collects.clear();
			double ang = 0.0;
			for (sint32 s = 0; s < 16; s++) {
				const auto sina = sin(ang);
				const auto cosa = cos(ang);
				for (sint32 m = 1; m < max_search_length; m++) {
					const sint32 yy = lround(y + m * sina);
					const sint32 xx = lround(x + m * cosa);
					if (yy < 0 || yy >= height || xx < 0 || xx >= width) { break; }
					//const auto& d = disp_left_[yy * width + xx];
					const auto& d = lDis.ptr<double>(yy)[xx]/disSc;

					if (d != Invalid_Float) {
						disp_collects.emplace_back(yy * width * 3 + 3 * xx, d);
						break;
					}
				}
				ang += pi / 16;
			}
			if (disp_collects.empty()) {
				continue;
			}

			// �������ƥ��������ѡ����ɫ������������Ӳ�ֵ
			// ������ڵ�������ѡ����С�Ӳ�ֵ
			if (k == 0) {
				sint32 min_dist = 9999;
				float32 d = 0.0f;
				//const auto color = ADColor(img_left_[y*width * 3 + 3 * x], img_left_[y*width * 3 + 3 * x + 1], img_left_[y*width * 3 + 3 * x + 2]);
				const auto color = ADColor((lImg.ptr<double>(y)+ 3 * x)[0]*255, (lImg.ptr<double>(y) + 3 * x)[1] * 255, (lImg.ptr<double>(y) + 3 * x)[2] * 255);

				for (auto& dc : disp_collects) {
					const auto color2 = ADColor((lImg.ptr<double>(dc.first/(wid*3))+(dc.first % (wid * 3)))[0]*255, (lImg.ptr<double>(dc.first / (wid * 3)) + (dc.first % (wid * 3)))[1] * 255, (lImg.ptr<double>(dc.first / (wid * 3)) + (dc.first % (wid * 3)))[2] * 255);
					const auto dist = abs(color.r - color2.r) + abs(color.g - color2.g) + abs(color.b - color2.b);
					if (min_dist > dist) {
						min_dist = dist;
						d = dc.second;
					}
				}
				fill_disps[n] = d;
			}
			else {
				float32 min_disp = Large_Float;
				for (auto& dc : disp_collects) {
					min_disp = std::min(min_disp, dc.second);
				}
				fill_disps[n] = min_disp;
			}
		}
		for (auto n = 0u; n < trg_pixels.size(); n++) {
			auto& pix = trg_pixels[n];
			const sint32 x = pix.first;
			const sint32 y = pix.second;
			lImg.ptr<double>(y)[x] = fill_disps[n]*disSc;
		}
	}
}

#ifdef _DEBUG
// global function to solve all cost volume
void SolveAll( SSCA**& smPyr, const int PY_LVL, const double REG_LAMBDA )
{
	printf( "\n\t\tSolve All" );
	printf( "\n\t\tReg param: %.4lf\n", REG_LAMBDA );
	// construct regularization matrix
	Mat regMat = Mat::zeros( PY_LVL, PY_LVL, CV_64FC1 );
	for( int s = 0; s < PY_LVL; s ++ ) {
		if( s == 0 ) {
			regMat.at<double>( s, s ) = 1 + REG_LAMBDA;
			regMat.at<double>( s, s + 1 ) = - REG_LAMBDA;
		} else if( s == PY_LVL - 1 ) {
			regMat.at<double>( s, s ) = 1 + REG_LAMBDA;
			regMat.at<double>( s, s - 1 ) = - REG_LAMBDA;
		} else {
			regMat.at<double>( s, s ) = 1 + 2 * REG_LAMBDA;
			regMat.at<double>( s, s - 1 ) = - REG_LAMBDA;
			regMat.at<double>( s, s + 1 ) = - REG_LAMBDA;
		}
	}
	Mat regInv = regMat.inv( );
	double* invWgt  = new double[ PY_LVL * PY_LVL ];
	for( int m = 0; m < PY_LVL; m ++ ) {
		double* sWgt = invWgt + m * PY_LVL;
		for( int s = 0; s < PY_LVL; s ++ ) {
			sWgt[ s ] = regInv.at<double>( m, s );
		}
	}

	PrintMat<double>( regInv );

	int hei = smPyr[ 0 ]->hei;
	int wid = smPyr[ 0 ]->wid;

	// backup all cost
	Mat** newCosts = new Mat*[ PY_LVL ];
	for( int s = 0; s < PY_LVL; s ++ ) {
		newCosts[ s ] = new Mat[ smPyr[ s ]->maxDis ];
		for( int d = 0; d < smPyr[ s ]->maxDis; d ++ ) {
			newCosts[ s ][ d ] = Mat::zeros( smPyr[ s ]->hei, smPyr[ s ]->wid, CV_64FC1  );
		}
	}

	for( int d = 1; d < smPyr[ 0 ]->maxDis; d ++ ) {
		printf( ".s.v." );
		for( int y = 0; y < hei; y ++ ) {
			for( int x = 0; x < wid; x ++ ) {
				for( int m = 0; m < PY_LVL; m ++ ) {
					double sum = 0.0f;
					double* sWgt = invWgt + m * PY_LVL;
					int curY = y;
					int curX = x;
					int curD = d;
					int assY = y;
					int assX = x;
					int assD = d;
					for( int s = 0; s < PY_LVL; s ++ ) {
						if( s == m ) {
							assY = curY;
							assX = curX;
							assD = curD;
						}
						double curCost = smPyr[ s ]->costVol[ curD ].at<double>( curY, curX );
						sum += sWgt[ s ] * curCost;
						curY = curY / 2;
						curX = curX / 2;
						curD = ( curD + 1 ) / 2;
					}
					newCosts[ m ][ assD ].at<double>( assY, assX ) = sum;
				}
			}
		}
	}

	for( int s = 0; s < PY_LVL; s ++ ) {
		for( int d = 0; d < smPyr[ s ]->maxDis; d ++ ) {
			smPyr[ s ]->costVol[ d ] = newCosts[ s ][ d ].clone();
		}
	}
	// PrintMat<double>( smPyr[ 0 ]->costVol[ 1 ] );
	delete [] invWgt;
	for( int s = 0; s < PY_LVL; s ++ ) {
		delete [ ] newCosts[ s ];
	}
	delete [] newCosts;
}

void saveOnePixCost( SSCA**& smPyr, const int PY_LVL )
{
	// save as matlab order
	FILE* fp = fopen( "onePix.txt", "w" );
	for( int y = 0; y < smPyr[ 0 ]->hei; y ++ ) {
		for( int x = 0; x < smPyr[ 0 ]->wid; x ++ ) {
			if( y == 24 && x == 443 ) {
				int curY = y;
				int curX = x;
				int prtTime = 1;
				for( int s = 0; s < PY_LVL; s ++ ) {
					fprintf( fp, "(%d,%d): ", curX, curY );
					for( int d = 1; d < smPyr[ s ]->maxDis; d ++ ) {
						double curCost = smPyr[ s ]->costVol[ d ].at<double>( curY, curX );
						for( int p = 0; p < prtTime; p ++ ) {
							fprintf( fp, " %lf", curCost );
						}
					}
					curY = curY / 2;
					curX = curX / 2;
					prtTime *= 2;
					fprintf( fp, "\n" );
				}
			}
		}
	}
	fclose( fp );
}

#else
// global function to solve all cost volume
void SolveAll( SSCA**& smPyr, const int PY_LVL, const double REG_LAMBDA )
{
	printf( "\n\t\tSolve All" );
	printf( "\n\t\tReg param: %.4lf\n", REG_LAMBDA );
	// construct regularization matrix
	Mat regMat = Mat::zeros( PY_LVL, PY_LVL, CV_64FC1 );
	for( int s = 0; s < PY_LVL; s ++ ) {
		if( s == 0 ) {
			regMat.at<double>( s, s ) = 1 + REG_LAMBDA;
			regMat.at<double>( s, s + 1 ) = - REG_LAMBDA;
		} else if( s == PY_LVL - 1 ) {
			regMat.at<double>( s, s ) = 1 + REG_LAMBDA;
			regMat.at<double>( s, s - 1 ) = - REG_LAMBDA;
		} else {
			regMat.at<double>( s, s ) = 1 + 2 * REG_LAMBDA;
			regMat.at<double>( s, s - 1 ) = - REG_LAMBDA;
			regMat.at<double>( s, s + 1 ) = - REG_LAMBDA;
		}
	}	

	Mat regInv = regMat.inv( );

	double* invWgt  = new double[ PY_LVL ];
	for( int s = 0; s < PY_LVL; s ++ ) {
		invWgt[ s ] = regInv.at<double>( 0, s );
	}
	PrintMat<double>( regInv );
	int hei = smPyr[ 0 ]->hei;
	int wid = smPyr[ 0 ]->wid;
	// PrintMat<double>( smPyr[ 0 ]->costVol[ 1 ] );
	// for each cost volume divide its mean value
	//for( int s = 0; s < PY_LVL; s++ ) {
	//	for( int y = 0; y < smPyr[ s ]->hei; y ++ ) {
	//		for( int x = 0; x < smPyr[ s ]->wid; x ++ ) {
	//			double meanD = 0;
	//			for( int d = 1; d < smPyr[ s ]->maxDis; d ++ ) {
	//				meanD += smPyr[ s ]->costVol[ d ].at<double>( y, x );
	//			}
	//			meanD /= ( smPyr[ s ]->maxDis - 1 );
	//			if( meanD == 0 ) {
	//				meanD = 1.0;
	//			}
	//			for( int d = 1; d < smPyr[ s ]->maxDis; d ++ ) {
	//				smPyr[ s ]->costVol[ d ].at<double>( y, x ) /= meanD;
	//			}
	//		}
	//	}
	//}
	

	//
	// Left Cost Volume
	//
	for( int d = 1; d < smPyr[ 0 ]->maxDis; d ++ ) {
		// printf( ".s.v." );
		for( int y = 0; y < hei; y ++ ) {
			for( int x = 0; x < wid; x ++ ) {
				int curY = y;
				int curX = x;
				int curD = d;
				double sum = 0;
				for( int s = 0; s < PY_LVL; s ++ ) {
					double curCost = smPyr[ s ]->costVol[ curD ].at<double>( curY, curX );
#ifdef _DEBUG
					if( y == 160 && x == 160 ) {
						printf( "\ns=%d(%d,%d)\td=%d\tcost=%.4lf", s, curY, curX, curD, curCost );
					}
#endif
					sum += invWgt[ s ] * curCost;
					curY = curY / 2;
					curX = curX / 2;
					curD = ( curD + 1 ) / 2;
				}
				smPyr[ 0 ]->costVol[ d ].at<double>( y, x ) = sum;
			//	printf("%f", sum);
			}
		}
	}

#ifdef COMPUTE_RIGHT
	//
	// Right Cost Volume
	//
	for( int d = 1; d < smPyr[ 0 ]->maxDis; d ++ ) {
		// printf( ".s.v." );
		for( int y = 0; y < hei; y ++ ) {
			for( int x = 0; x < wid; x ++ ) {
				int curY = y;
				int curX = x;
				int curD = d;
				double sum = 0;
				for( int s = 0; s < PY_LVL; s ++ ) {
					double curCost = smPyr[ s ]->rCostVol[ curD ].at<double>( curY, curX );
#ifdef _DEBUG
					if( y == 160 && x == 160 ) {
						printf( "\ns=%d(%d,%d)\td=%d\tcost=%.4lf", s, curY, curX, curD, curCost );
					}
#endif
					sum += invWgt[ s ] * curCost;
					curY = curY / 2;
					curX = curX / 2;
					curD = ( curD + 1 ) / 2;
				}
				smPyr[ 0 ]->rCostVol[ d ].at<double>( y, x ) = sum;

			}
		}
	}
#endif
	// PrintMat<double>( smPyr[ 0 ]->costVol[ 1 ] );
	delete [] invWgt;
}

#endif

