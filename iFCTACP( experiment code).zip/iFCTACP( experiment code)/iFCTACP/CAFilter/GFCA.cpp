#include "GFCA.h"
#include "GuidedFilter.h"


void GFCA::aggreCV( const Mat& lImg, const Mat& rImg, const int maxDis, Mat* costVol, Mat* cost_compute)
{
	// filtering cost volume
	for( int d = 1; d < maxDis; d ++ ) {
		printf( "-c-a" );
		costVol[ d ] = GuidedFilter( lImg, costVol[ d ] );
	}
}
