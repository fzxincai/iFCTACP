#include "IC.h"
#include <math.h>
#include "cross_aggregator.h"
sint32 ColorDist1(const ADColor& c1, const ADColor& c2)  {
	return std::max(abs(c1.r - c2.r), std::max(abs(c1.g - c2.g), abs(c1.b - c2.b)));
}
float Median(float a[], int N)
{
	int i, j, max;
	int t;
	for (i = 0; i < N - 1; i++)
	{
		max = i;
		for (j = i + 1; j < N; j++)
			if (a[j] > a[max]) max = j;
		t = a[i]; a[i] = a[max]; a[max] = t;
	}
	return a[(N - 1) / 2];
}

void census_transform_7x9(Mat Gray, vector<uint64>& census, const int width, const int height, Mat Img)
{
	if (Gray.empty() || census.empty() || width <= 5 || height <= 5) {
		return;
	}
//	Gray.convertTo(Gray, CV_64F, 255.0f);
	Mat Grd, GrdX, GrdY;
	Sobel(Gray, GrdX, CV_64F, 1, 0, 1);
	Sobel(Gray, GrdY, CV_64F, 0, 1, 1);
	GrdX.convertTo(GrdX, CV_64F, 255.0f);
	GrdY.convertTo(GrdY, CV_64F, 255.0f);
	
	GrdX.copyTo(Grd);

	for (int i = 1; i < height - 1; i++) {
		for (int j = 1; j < width - 1; j++) {
			double t = 0;
			for (int r = -1; r <= 1; r++) {
				for (int c = -1; c <= 1; c++) {
					//printf("%f\t", GrdX.ptr<double>(i + r)[j + c]);
					//printf("%f\n", GrdY.ptr<double>(i + r)[j + c]);
					t += abs(GrdX.ptr<double>(i + r)[j + c]) + abs(GrdY.ptr<double>(i + r)[j + c]);
				}
			}
			Grd.ptr<double>(i)[j] = t / 9.0;
		}
	}
	
	/***************CT*******************/
/*	for (int i = 3; i < height - 3; i++) {
		for (int j = 4; j < width - 4; j++) {
			float gray_center, sum = 0.0,mean=0 ;
			int count = 0;
			//for (int r = -2; r <= 2; r++) {
			//	for (int c = -2; c <= 2; c++) {
			//		sum+= Gray.ptr<float>(i + r)[j + c];
			//		count++;
			//	}
			//}
			//mean = sum / count;
			//gray_center = mean;
			gray_center = Gray.ptr<float>(i)[j];
			uint64 census_val = 0u;
			for (int r = -3; r <= 3; r++) {
				for (int c = -4; c <= 4; c++) {
					census_val <<= 1;
					//const uint8 gray = source[(i + r) * width + j + c];
					float gray = Gray.ptr<float>(i + r)[j + c];
					if (gray < gray_center) {
						census_val += 1;
					}
				}
			}
			// �������ص�censusֵ
			census[i * width + j] = census_val;
		}
	}*/
	

	/**************MCT*********************/
	/*for (int i = 3; i < height - 3; i++) {
		for (int j = 3; j < width - 3; j++) {
			float gray_center, sum = 0.0, mean = 0;
			int count = 0;
			for (int r = -3; r <= 3; r++) {
				for (int c = -3; c <= 3; c++) {
					sum+= Gray.ptr<float>(i + r)[j + c];
					count++;
				}
			}
			mean = sum / count;
			gray_center = mean;
			//gray_center = Gray.ptr<float>(i)[j];
			uint64 census_val = 0u;
			for (int r = -3; r <= 3; r++) {
				for (int c = -3; c <= 3; c++) {
					census_val <<= 1;
					//const uint8 gray = source[(i + r) * width + j + c];
					float gray = Gray.ptr<float>(i + r)[j + c];
					if (gray < gray_center) {
						census_val += 1;
					}
				}
			}
			// �������ص�censusֵ
			census[i * width + j] = census_val;
		}
	}*/


	/****************��ģ̬********************/
/*	for (int i = 3; i < height - 3; i++) {
		for (int j = 3; j < width - 3; j++) {
			float gray_center, sum1 = 0.0, sum2 = 0.0;
			int count1 = 0,a=0, count2 = 0;
			
			for (int r = -3; r <= 3; r++) {
				for (int c = -3; c <= 3; c++) {
					if (Gray.ptr<float>(i + r)[j + c] > Gray.ptr<float>(i)[j]) {
						sum1 += Gray.ptr<float>(i + r)[j + c];
						count1++;
					}
					else {
						sum2+= Gray.ptr<float>(i + r)[j + c];
						count2++;
					}
				}
			}
			a= ((sum1 / count1) - (sum2 / count2)) / (32.0/255);
			gray_center = Gray.ptr<float>(i)[j];
			uint64 census_val = 0u;
			for (int r = -3; r <= 3; r++) {
				for (int c = -3; c <=3; c++) {
					
					float gray = Gray.ptr<float>(i + r)[j + c];
					census_val <<= 1;
					if (gray >= gray_center + a)
					{
						census_val += 1;
						census_val <<= 1;
						census_val += 1;
					}
					else if (gray >= gray_center && gray < gray_center + a)
					{
						census_val += 1;
						census_val <<= 1;
					}
					else if (gray >= gray_center - a && gray < gray_center) {
						census_val <<= 1;
						census_val += 1;
					}
					else {
						census_val <<= 1;
					}
				}
			}
			// �������ص�censusֵ
			census[i * width + j] = census_val;
		}
	}
*/
	/********************SCI(2018 A novel non-parametric transform stereo matching method
based on mutual relationship)**********************/

	/*for (int i = 3; i < height - 3; i++) {
		for (int j = 3; j < width - 3; j++) {
			float mean = 0,sum=0,count=0, gray_center;
			for (int r = -3; r <= 3; r++) {
				for (int c = -3; c <= 3; c++) {
					sum = Gray.ptr<float>(i - 1)[j - 1];
				}
			}
			mean = sum / count;
			gray_center = mean;
			Gray.ptr<float>(i)[j] = gray_center;
			
			//3*3
			Gray.ptr<float>(i - 1)[j - 1] = 0.25*(Gray.ptr<float>(i - 1)[j - 1] + Gray.ptr<float>(i - 1)[j] + Gray.ptr<float>(i)[j - 1] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i - 1)[j + 1] = 0.25*(Gray.ptr<float>(i - 1)[j +1] + Gray.ptr<float>(i - 1)[j] + Gray.ptr<float>(i)[j +1] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i + 1)[j - 1] = 0.25*(Gray.ptr<float>(i)[j - 1] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i+1)[j - 1] + Gray.ptr<float>(i+1)[j]);
			Gray.ptr<float>(i + 1)[j + 1] = 0.25*(Gray.ptr<float>(i )[j ] + Gray.ptr<float>(i)[j+1] + Gray.ptr<float>(i+1)[j] + Gray.ptr<float>(i+1)[j+1]);
			//5*5
			Gray.ptr<float>(i -1)[j -2] = 0.25*(Gray.ptr<float>(i-1)[j-2] + Gray.ptr<float>(i-1)[j] + Gray.ptr<float>(i)[j-2] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i - 2)[j - 2] = 0.25*(Gray.ptr<float>(i - 2)[j - 2] + Gray.ptr<float>(i - 2)[j] + Gray.ptr<float>(i)[j - 2] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i - 2)[j - 1] = 0.25*(Gray.ptr<float>(i - 2)[j - 1] + Gray.ptr<float>(i - 2)[j] + Gray.ptr<float>(i)[j - 1] + Gray.ptr<float>(i)[j]);

			Gray.ptr<float>(i - 2)[j + 1] = 0.25*(Gray.ptr<float>(i - 2)[j] + Gray.ptr<float>(i - 2)[j+1] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j+1]);
			Gray.ptr<float>(i - 2)[j + 2] = 0.25*(Gray.ptr<float>(i - 2)[j] + Gray.ptr<float>(i - 2)[j + 2] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 2]);
			Gray.ptr<float>(i - 1)[j + 2] = 0.25*(Gray.ptr<float>(i - 1)[j] + Gray.ptr<float>(i - 1)[j + 2] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 2]);

			Gray.ptr<float>(i +1)[j - 2] = 0.25*(Gray.ptr<float>(i)[j-2] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i+1)[j-2] + Gray.ptr<float>(i+1)[j]);
			Gray.ptr<float>(i + 2)[j - 2] = 0.25*(Gray.ptr<float>(i)[j - 2] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i + 2)[j - 2] + Gray.ptr<float>(i + 2)[j]);
			Gray.ptr<float>(i + 2)[j - 1] = 0.25*(Gray.ptr<float>(i)[j - 1] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i + 2)[j - 1] + Gray.ptr<float>(i + 2)[j]);

			Gray.ptr<float>(i + 1)[j + 2] = 0.25*(Gray.ptr<float>(i)[j ] + Gray.ptr<float>(i)[j+2] + Gray.ptr<float>(i + 1)[j ] + Gray.ptr<float>(i + 1)[j+2]);
			Gray.ptr<float>(i + 2)[j + 2] = 0.25*(Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j+2] + Gray.ptr<float>(i + 2)[j] + Gray.ptr<float>(i + 2)[j+2]);
			Gray.ptr<float>(i + 2)[j + 1] = 0.25*(Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 1] + Gray.ptr<float>(i + 2)[j] + Gray.ptr<float>(i + 2)[j + 1]);

			//7*7
			Gray.ptr<float>(i - 1)[j -3] = 0.25*(Gray.ptr<float>(i-1)[j-3] + Gray.ptr<float>(i-1)[j] + Gray.ptr<float>(i)[j-3] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i - 2)[j - 3] = 0.25*(Gray.ptr<float>(i - 2)[j - 3] + Gray.ptr<float>(i - 2)[j] + Gray.ptr<float>(i)[j - 3] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i - 3)[j - 3] = 0.25*(Gray.ptr<float>(i - 3)[j - 3] + Gray.ptr<float>(i - 3)[j] + Gray.ptr<float>(i)[j - 3] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i - 3)[j - 2] = 0.25*(Gray.ptr<float>(i - 3)[j -2] + Gray.ptr<float>(i - 3)[j] + Gray.ptr<float>(i)[j - 2] + Gray.ptr<float>(i)[j]);
			Gray.ptr<float>(i - 3)[j - 1] = 0.25*(Gray.ptr<float>(i - 3)[j - 1] + Gray.ptr<float>(i - 3)[j] + Gray.ptr<float>(i)[j - 1] + Gray.ptr<float>(i)[j]);

			Gray.ptr<float>(i -3)[j+1] = 0.25*(Gray.ptr<float>(i - 3)[j] + Gray.ptr<float>(i - 3)[j+1] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j+1]);
			Gray.ptr<float>(i - 3)[j + 2] = 0.25*(Gray.ptr<float>(i - 3)[j] + Gray.ptr<float>(i - 3)[j + 2] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 2]);
			Gray.ptr<float>(i - 3)[j +3] = 0.25*(Gray.ptr<float>(i - 3)[j] + Gray.ptr<float>(i - 3)[j + 3] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 3]);
			Gray.ptr<float>(i - 2)[j + 3] = 0.25*(Gray.ptr<float>(i - 2)[j] + Gray.ptr<float>(i - 2)[j + 3] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 3]);
			Gray.ptr<float>(i - 1)[j + 3] = 0.25*(Gray.ptr<float>(i - 1)[j] + Gray.ptr<float>(i - 1)[j + 3] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 3]);

			Gray.ptr<float>(i +1)[j - 3] = 0.25*(Gray.ptr<float>(i)[j-3] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i+1)[j-3] + Gray.ptr<float>(i+1)[j]);
			Gray.ptr<float>(i + 2)[j - 3] = 0.25*(Gray.ptr<float>(i)[j - 3] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i + 2)[j - 3] + Gray.ptr<float>(i + 2)[j]);
			Gray.ptr<float>(i + 3)[j - 3] = 0.25*(Gray.ptr<float>(i)[j - 3] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i + 3)[j - 3] + Gray.ptr<float>(i + 3)[j]);
			Gray.ptr<float>(i + 3)[j - 2] = 0.25*(Gray.ptr<float>(i)[j - 2] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i + 3)[j - 2] + Gray.ptr<float>(i + 3)[j]);
			Gray.ptr<float>(i + 3)[j - 1] = 0.25*(Gray.ptr<float>(i)[j - 1] + Gray.ptr<float>(i)[j] + Gray.ptr<float>(i + 3)[j - 1] + Gray.ptr<float>(i + 3)[j]);

			Gray.ptr<float>(i + 1)[j +3] = 0.25*(Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j+3] + Gray.ptr<float>(i + 1)[j] + Gray.ptr<float>(i + 1)[j+3]);
			Gray.ptr<float>(i + 2)[j + 3] = 0.25*(Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 3] + Gray.ptr<float>(i + 2)[j] + Gray.ptr<float>(i + 2)[j + 3]);
			Gray.ptr<float>(i + 3)[j + 3] = 0.25*(Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 3] + Gray.ptr<float>(i + 3)[j] + Gray.ptr<float>(i + 3)[j + 3]);
			Gray.ptr<float>(i + 3)[j + 2] = 0.25*(Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 2] + Gray.ptr<float>(i + 3)[j] + Gray.ptr<float>(i + 3)[j + 2]);
			Gray.ptr<float>(i + 3)[j + 1] = 0.25*(Gray.ptr<float>(i)[j] + Gray.ptr<float>(i)[j + 1] + Gray.ptr<float>(i + 3)[j] + Gray.ptr<float>(i + 3)[j + 1]);


			uint64 census_val = 0u;
			for (int r = -3; r <= 3; r++) {
				for (int c = -3; c <= 3; c++) {
					census_val <<= 1;
					//const uint8 gray = source[(i + r) * width + j + c];
					float gray = Gray.ptr<float>(i + r)[j + c];
					if (gray < gray_center) {
						census_val += 1;
					}
				}
			}
			// �������ص�censusֵ
			census[i * width + j] = census_val;
		}
	}*/

/*******************SCI(2016 Improved census transform for noise robust stereo
matching)*********************/
	/*for (int i = 3; i < height - 3; i++) {
		for (int j = 3; j < width - 3; j++) {
			uint64 census_val = 0u;
			census_val <<= 1;
			if (Gray.ptr<float>(i - 2)[j - 2] > Gray.ptr<float>(i - 2)[j]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i - 2)[j] > Gray.ptr<float>(i - 1)[j+2]) {
				census_val += 1;
			}
			
			census_val <<= 1;
			if (Gray.ptr<float>(i -1)[j + 2] > Gray.ptr<float>(i+1)[j]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i +1)[j ] > Gray.ptr<float>(i + 2)[j-2]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i + 2)[j - 2] > Gray.ptr<float>(i)[j-2]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i)[j - 2] > Gray.ptr<float>(i-2)[j - 1]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i - 2)[j - 1] > Gray.ptr<float>(i)[j+1]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i)[j + 1] > Gray.ptr<float>(i+2)[j +2]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i + 2)[j + 2] > Gray.ptr<float>(i + 2)[j]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i + 2)[j] > Gray.ptr<float>(i + 1)[j-2]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i +1)[j-2] > Gray.ptr<float>(i - 1)[j]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i - 1)[j] > Gray.ptr<float>(i - 2)[j+2]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i - 2)[j+2] > Gray.ptr<float>(i)[j + 2]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i)[j + 2] > Gray.ptr<float>(i+2)[j + 1]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i + 2)[j + 1] > Gray.ptr<float>(i)[j - 1]) {
				census_val += 1;
			}

			census_val <<= 1;
			if (Gray.ptr<float>(i)[j - 1] > Gray.ptr<float>(i-2)[j -2]) {
				census_val += 1;
			}

			census[i * width + j] = census_val;
		}
	}*/
	

	// �����ؼ���Ҷ�ֵ��censusֵ
	/*for (int i = 3; i < height - 3; i++) {
		for (int j = 4; j < width - 4; j++) {
			float gray_center, gray_temp = 0.0, count = 0;

			gray_center= Gray.ptr<float>(i)[j];
			// ������СΪ5x5�Ĵ������������أ���һ�Ƚ�����ֵ����������ֵ�ĵĴ�С������censusֵ
			uint64 census_val = 0u;
			for (int r = -3; r <= 3; r++) {
				for (int c = -4; c <= 4; c++) {
					census_val <<= 1;
					//const uint8 gray = source[(i + r) * width + j + c];
					float gray = Gray.ptr<float>(i + r)[j + c];
					if (gray < gray_center) {
						census_val += 1;
					}
				}
			}

			// �������ص�censusֵ
			census[i * width + j] = census_val;
		}
	}*/
		

	/*����*/
for (int i = 2; i < height - 2; i++) {
	for (int j = 2; j < width - 2; j++) {
		float gray_center, gray_temp = 0.0, count1 = 0, count2 = 0, count3 = 0, count4 = 0,count5=0;
		float mean1 = 0, mean2 = 0, mean3 = 0, mean4 = 0,sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0,sum5=0;
		float a[10] = { 0 }, amin = 999.0, b[25] = { 0 }, med, gua = 0, h[10] = {0};
		int d = 0, k,m=0,l=0;

		for (int r = -2; r <= 2; r++) {
			for (int c = -2; c <= 2; c++) {
				//printf("����Ϊ��%d,%d,%f\t", (i + r), (j + c), Gray.ptr<float>(i + r)[j + c]*255);
				k = 0;
				sum1 += Gray.ptr<float>(i + r)[j + c];
				count1++;
				b[m]= Gray.ptr<float>(i + r)[j + c];
				m++;
				if ((i + r) != 0 && (i + r) != height - 1 && (j + c) != 0 && (j + c) != width - 1) {
					for (int m = -1; m <= 1; m++) {
						for (int n = -1; n <= 1; n++) {
							
							if (m != 0 && n != 0) {
								a[k] = pow(abs(pow(Gray.ptr<float>(i + r + m)[j + c + n], 2) - pow(Gray.ptr<float>(i + r)[j + c], 2)), 0.5);
								k++;
							}
						}
					}
				}
				for (int b = 0; b < k; b++) {
					if (a[b] < amin) {
						amin = a[b];
					}
				}
				
				//if (amin < 0.085) {
				//	sum2 += Gray.ptr<float>(i + r)[j + c];
				//	count2++;					
				//}
				//printf("%f\t", abs(Gray.ptr<float>(i + r)[j + c] - Gray.ptr<float>(i)[j]));
				if (abs(Gray.ptr<float>(i + r)[j + c]- Gray.ptr<float>(i)[j])<=12/255.0) {
					sum2 += Gray.ptr<float>(i + r)[j + c];
					count2++;
					
				}
				if (Gray.ptr<float>(i + r)[j + c] > Gray.ptr<float>(i)[j])
				{
					sum3 += Gray.ptr<float>(i + r)[j + c];
					count3 += 1;
				}
				else {
					sum4 += Gray.ptr<float>(i + r)[j + c];
					count4 += 1;
				}
				
			}
		}
		mean1 = sum1 / count1;
		mean2 = (sum2) / (count2 );
		d = ((sum3 / count3) - (sum4 / count4)) / ( 32/ 255.0);
		mean3 = sum3 / count3;
		
		for (int r = -1; r <= 1; r++) {
			for (int c = -1; c <= 1; c++) {
				//h[l] = Gray.ptr<float>(i + r)[j + c];
				sum5 += Gray.ptr<float>(i + r)[j + c];
				count5++;
				//l++;
			}
		}
		
		mean4 = (sum5 ) / (count5 );
		gray_center= Gray.ptr<float>(i )[j];
		uint64 census_val = 0u;
		if(i>=3&&i< height-3&&j>=3&&j< width - 3){
		for (int r = -3; r <= 3; r++) {
			for (int c = -3; c <= 3; c++) {
				float gray = Gray.ptr<float>(i + r)[j + c];				

				census_val <<= 1;
				if (gray < gray_center&&gray > mean4) {
					census_val <<= 1;
					census_val += 1;
				}
				else if (gray > gray_center&&gray < mean4) {
					census_val += 1;
					census_val <<= 1;
				}
				else if (gray <= min(gray_center, mean4)) {
					census_val <<= 1;
				}
				else if (gray >= max(gray_center, mean4)) {
					census_val += 1;
					census_val <<= 1;
					census_val += 1;
				}
				
			}
		}
		census[i * width + j] = census_val;
		}
		else {
			for (int r = -2; r <= 2; r++) {
				for (int c = -2; c <= 2; c++) {
					float gray = Gray.ptr<float>(i + r)[j + c];					
					census_val <<= 1;
					if (gray <gray_center&&gray > mean4) {
						census_val <<= 1;
						census_val += 1;
					}
					else if (gray > gray_center&&gray < mean4) {
						census_val += 1;
						census_val <<= 1;
					}
					else if (gray <= min(gray_center, mean4)) {
						census_val <<= 1;
					}
					else if (gray >= max(gray_center, mean4)) {
						census_val += 1;
						census_val <<= 1;
						census_val += 1;
					}

				}
			}
			census[i * width + j] = census_val;
		}		
	}
}

}

uint Hamming64(const uint64& x, const uint64& y)
{
	uint64 dist = 0, val = x ^ y;

	// Count the number of set bits
	while (val) {
		++dist;
		val &= val - 1;
	}

	return static_cast<uint>(dist);
}


inline double ICmyCostGrd(double* lC, double* rC,
	double* lG, double* rG)
{
	double clrDiff = 0;
	// three color
	for (int c = 0; c < 3; c++) {
		double temp = fabs(lC[c] - rC[c]);
		clrDiff += temp;
	}
	clrDiff *= 0.3333333333;
	// gradient diff
	double grdDiff = fabs(lG[0] - rG[0]);
	clrDiff = clrDiff > TAU_1 ? TAU_1 : clrDiff;
	grdDiff = grdDiff > TAU_2 ? TAU_2 : grdDiff;
	return ALPHA * clrDiff + (1 - ALPHA) * grdDiff;
}
// specail handle for border region
inline double ICmyCostGrd(double* lC, double* lG)
{
	double clrDiff = 0;
	// three color
	for (int c = 0; c < 3; c++) {
		double temp = fabs(lC[c] - BORDER_CONSTANT);
		clrDiff += temp;
	}
	clrDiff *= 0.3333333333;
	// gradient diff
	double grdDiff = fabs(lG[0] - BORDER_CONSTANT);
	clrDiff = clrDiff > TAU_1 ? TAU_1 : clrDiff;
	grdDiff = grdDiff > TAU_2 ? TAU_2 : grdDiff;
	return ALPHA * clrDiff + (1 - ALPHA) * grdDiff;
}
// compute gradient by your code! not opencv!
void ICmyComputeGradient(const Mat& grayImg, Mat& grd)
{
	int m_h = grayImg.rows;
	int m_w = grayImg.cols;
	grd = Mat::zeros(m_h, m_w, CV_64FC1);
	float gray, gray_minus, gray_plus;
	for (int y = 0; y < m_h; y++)
	{
		float* grayData = (float*)grayImg.ptr<float>(y);
		double* grdData = (double*)grd.ptr<double>(y);
		gray_minus = grayData[0];
		gray = gray_plus = grayData[1];
		grdData[0] = gray_plus - gray_minus + 0.5;
		for (int x = 1; x < m_w - 1; x++)
		{
			gray_plus = grayData[x + 1];
			grdData[x] = 0.5 * (gray_plus - gray_minus) + 0.5;
			gray_minus = gray;
			gray = gray_plus;
		}
		grdData[m_w - 1] = gray_plus - gray_minus + 0.5;
	}
}


void IC::buildCV(const Mat& lImg, const Mat& rImg, const int maxDis, Mat* costVol, Mat* cost_compute)
{

	

	// for TAD + Grd input image must be CV_64FC3
	CV_Assert(lImg.type() == CV_64FC3 && rImg.type() == CV_64FC3);

	int hei = lImg.rows;
	int wid = lImg.cols;
	Mat lGray, rGray;
	Mat lGrdX, rGrdX;
	Mat lGrdY, rGrdY;
	Mat tmp;
	/** \brief ��Ӱ��census����	*/
//	vector<uint64> census_left_;
	/** \brief ��Ӱ��census����	*/
//	vector<uint64> census_right_;

	lImg.convertTo(tmp, CV_32F);
	cvtColor(tmp, lGray, CV_RGB2GRAY);
	rImg.convertTo(tmp, CV_32F);
	cvtColor(tmp, rGray, CV_RGB2GRAY);

	// census���ݣ�����Ӱ��
	// X Gradient
	// sobel size must be 1
	Sobel(lGray, lGrdX, CV_64F, 1, 0, 1);
	Sobel(lGray, lGrdY, CV_64F, 0, 1, 1);

	Sobel(rGray, rGrdX, CV_64F, 1, 0, 1);
	Sobel(rGray, rGrdY, CV_64F, 0, 1, 1);
	lGrdX += 0.5;
	lGrdY += 0.5;
	rGrdX += 0.5;
	lGrdY += 0.5;

	cv::Mat xylGrd = Mat(lGrdX.size(), lGrdX.type()), xyrGrd = Mat(lGrdX.size(), lGrdX.type());

	for (int i = 0; i < hei; i++) {
		for (int j = 0; j < wid; j++) {
			double lxg = lGrdX.ptr<double>(i)[j];
			double lyg = lGrdY.ptr<double>(i)[j];
			double lxy = abs(lxg) + abs(lyg);
			xylGrd.ptr<double>(i)[j] = saturate_cast<double>(lxy);

			double rxg = rGrdX.ptr<double>(i)[j];
			double ryg = rGrdY.ptr<double>(i)[j];
			double rxy = abs(rxg) + abs(ryg);
			xyrGrd.ptr<double>(i)[j] = saturate_cast<double>(rxy);
		}
	}
	/** \brief ��Ӱ��census����	*/
	vector<uint64> census_left_;
	/** \brief ��Ӱ��census����	*/
	vector<uint64> census_right_;
	// census���ݣ�����Ӱ��
	census_left_.resize(hei*wid, 0);
	census_right_.resize(hei*wid, 0);

	vector<uint64> h;
	h.resize(hei*wid, 0);
	
	
	census_transform_7x9(lGray, census_left_, wid, hei, lImg);
		
	census_transform_7x9(rGray, census_right_, wid, hei, rImg);


	

	// build cost volume! start from 1
	// try 0
	for (int d = 0; d < maxDis; d++) {
		printf("-c-c-");
		for (int y = 0; y < hei; y++) {
			double* lData = (double*)lImg.ptr<double>(y);
			double* rData = (double*)rImg.ptr<double>(y);
			double* lGData = (double*)lGrdX.ptr<double>(y);
			double* rGData = (double*)rGrdX.ptr<double>(y);
			double* cost = (double*)costVol[d].ptr<double>(y);
			for (int x = 0; x < wid; x++) {



				if (x - d >= 0) {
					double* lC = lData + 3 * x;
					double* rC = rData + 3 * (x - d);
					double* lG = lGData + x;
					double* rG = rGData + x - d;
					//*************************************************//
					const auto& census_val_l = census_left_[y * wid + x];
					const auto& census_val_r = census_right_[y * wid + x - d];
					

					double clrDiff = 0;
					// three color
					for (int c = 0; c < 3; c++) {
						double temp = fabs(lC[c] - rC[c]);
						clrDiff += temp;
					}
					clrDiff *= 0.3333333333;
					// gradient diff
					double grdDiff = fabs(lG[0] - rG[0]);
					clrDiff = clrDiff > TAU_1 ? TAU_1 : clrDiff;
					grdDiff = grdDiff > TAU_2 ? TAU_2 : grdDiff;

					const double cost_census = static_cast<double>(Hamming64(census_val_l, census_val_r));

					cost[x] = ALPHA * clrDiff + (1 - ALPHA) * (grdDiff);  
					
					h[y*wid + x] = cost_census;

				
					cost[x] = (1 - exp(-cost_census /cost1))/255+(1- exp(-255 * cost[x] /cost2));
				//	cost[x] = cost_census;
					cost_compute[d].ptr<double>(y)[x] = cost[x];
					
				}
				else {
					double* lC = lData + 3 * x;
					double* lG = lGData + x;
					//***************************************************
					double clrDiff = 0;
					// three color
					for (int c = 0; c < 3; c++) {
						double temp = fabs(lC[c] - BORDER_CONSTANT);
						clrDiff += temp;
					}
					clrDiff *= 0.3333333333;
					// gradient diff
					double grdDiff = fabs(lG[0] - BORDER_CONSTANT);
					clrDiff = clrDiff > TAU_1 ? TAU_1 : clrDiff;
					grdDiff = grdDiff > TAU_2 ? TAU_2 : grdDiff;
					cost[x] = ALPHA * clrDiff + (1 - ALPHA) * grdDiff;
					

				}				
			}
		}
	}
}


#ifdef COMPUTE_RIGHT
void IC::buildRightCV(const Mat& lImg, const Mat& rImg, const int maxDis, Mat* rCostVol)
{
	// for TAD + Grd input image must be CV_64FC3
	CV_Assert(lImg.type() == CV_64FC3 && rImg.type() == CV_64FC3);

	int hei = lImg.rows;
	int wid = lImg.cols;
	Mat lGray, rGray;
	Mat lGrdX, rGrdX;
	Mat lGrdY, rGrdY;
	Mat tmp;
	/** \brief ��Ӱ��census����	*/
//	vector<uint64> census_left_;
	/** \brief ��Ӱ��census����	*/
//	vector<uint64> census_right_;

	lImg.convertTo(tmp, CV_32F);
	cvtColor(tmp, lGray, CV_RGB2GRAY);
	rImg.convertTo(tmp, CV_32F);
	cvtColor(tmp, rGray, CV_RGB2GRAY);


	// census���ݣ�����Ӱ��
	// X Gradient
	// sobel size must be 1
	Sobel(lGray, lGrdX, CV_64F, 1, 0, 1);
	Sobel(lGray, lGrdY, CV_64F, 0, 1, 1);

	Sobel(rGray, rGrdX, CV_64F, 1, 0, 1);
	Sobel(rGray, rGrdY, CV_64F, 0, 1, 1);
	lGrdX += 0.5;
	lGrdY += 0.5;
	rGrdX += 0.5;
	lGrdY += 0.5;

	cv::Mat xylGrd = Mat(lGrdX.size(), lGrdX.type()), xyrGrd = Mat(lGrdX.size(), lGrdX.type());
	for (int i = 0; i < hei; i++) {
		for (int j = 0; j < wid; j++) {
			double lxg = lGrdX.ptr<double>(i)[j];
			double lyg = lGrdY.ptr<double>(i)[j];
			double lxy = abs(lxg) + abs(lyg);
			xylGrd.ptr<double>(i)[j] = saturate_cast<double>(lxy);

			double rxg = rGrdX.ptr<double>(i)[j];
			double ryg = rGrdY.ptr<double>(i)[j];
			double rxy = abs(rxg) + abs(ryg);
			xyrGrd.ptr<double>(i)[j] = saturate_cast<double>(rxy);
		}
	}

	/** \brief ��Ӱ��census����	*/
	vector<uint64> census_left_;
	/** \brief ��Ӱ��census����	*/
	vector<uint64> census_right_;
	// census���ݣ�����Ӱ��
	census_left_.resize(hei*wid, 0);
	census_right_.resize(hei*wid, 0);

	
	

	census_transform_7x9(lGray, census_left_, wid, hei, lImg);
	census_transform_7x9(rGray, census_right_, wid, hei, rImg);

	// build cost volume! start from 1
	// try 0
	for (int d = 0; d < maxDis; d++) {
		printf("-r-c-c-");
		for (int y = 0; y < hei; y++) {
			double* lData = (double*)lImg.ptr<double>(y);
			double* rData = (double*)rImg.ptr<double>(y);
			double* lGData = (double*)lGrdX.ptr<double>(y);
			double* rGData = (double*)rGrdX.ptr<double>(y);
			double* cost = (double*)rCostVol[d].ptr<double>(y);
			for (int x = 0; x < wid; x++) {



				if (x + d < wid) {
					double* rC = rData + 3 * x;
					double* lC = lData + 3 * (x + d);
					double* rG = rGData + x;
					double* lG = lGData + x + d;

					//*************************************************//
					const auto& census_val_l = census_left_[y * wid + x+d];
					const auto& census_val_r = census_right_[y * wid + x];
					double clrDiff = 0;
					// three color
					for (int c = 0; c < 3; c++) {
						double temp = fabs(lC[c] - rC[c]);
						clrDiff += temp;
					}
					clrDiff *= 0.3333333333;
					// gradient diff
					double grdDiff = fabs(lG[0] - rG[0]);
					clrDiff = clrDiff > TAU_1 ? TAU_1 : clrDiff;
					grdDiff = grdDiff > TAU_2 ? TAU_2 : grdDiff;

					const double cost_census = static_cast<double>(Hamming64(census_val_l, census_val_r));
					
					  cost[x] = ALPHA * clrDiff + (1 - ALPHA) * grdDiff;
				  
					  cost[x] = (1 - exp(-cost_census /cost1)) / 255 + (1 - exp(-255 * cost[x] /cost2));
			
				
				}
				else {
					double* rC = rData + 3 * x;
					double* rG = rGData + x;

					//***************************************************			
					double clrDiff = 0;
					// three color
					for (int c = 0; c < 3; c++) {
						double temp = fabs(rC[c] - BORDER_CONSTANT);
						clrDiff += temp;
					}
					clrDiff *= 0.3333333333;
					// gradient diff
					double grdDiff = fabs(rG[0] - BORDER_CONSTANT);
					clrDiff = clrDiff > TAU_1 ? TAU_1 : clrDiff;
					grdDiff = grdDiff > TAU_2 ? TAU_2 : grdDiff;
				
					cost[x] = ALPHA * clrDiff + (1 - ALPHA) * grdDiff;
					
				
				}
			}
		}
	}
}
#endif