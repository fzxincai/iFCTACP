///////////////////////////////////////////////////////
// File: GetMethod
// Desc: Get all the method interface by name
//
// Author: Zhang Kang
// Date: 2013/09/06
///////////////////////////////////////////////////////
#pragma  once

#include "CAFilter/GFCA.h"

#include "CANLC/NLCCA.h"
#include "CAST/STCA.h"
#include "PPWM/WMPP.h"

#include "CROSS.h"

#include "IC.h"

// get cost compuation method name
CCMethod* getCCType( const string name ) 
{
	if (name == "IC") {
		return new IC();
	}
}

// get cost aggregation method name
CAMethod* getCAType( const string name )
{
	if( name == "GF" ) {
		return new GFCA();
	} else if( name == "NL" ) {
		return new NLCCA();
	} else if ( name == "ST" ) {
		return new STCA();
	}
	else if (name == "CROSS") {
		return new CROSS();
	}
}
// get cost compuation method name
PPMethod* getPPType( const string name ) 
{
	 if( name == "WM" ) {
		return new WMPP();
	} 
}